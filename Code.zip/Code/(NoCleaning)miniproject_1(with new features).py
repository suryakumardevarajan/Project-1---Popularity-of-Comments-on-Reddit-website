#import json # we need to use the JSON package to load the data, since the data is stored in JSON format
import numpy as np
import pandas as pd
import collections
import time
from numpy import array, dot, transpose
from numpy.linalg import inv
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
import re
######################################### Importing the dataset ###############

dataset = pd.read_csv("input.csv")
######################################## data cleaning ########################

dataset['popularity_score'].fillna(dataset['popularity_score'].median(), inplace=True)
dataset['children'].fillna(0, inplace=True)
dataset['controversiality'].fillna(0, inplace=True)
dataset['is_root'].fillna("False", inplace=True)
dataset['text'].fillna("A", inplace=True)
dataset['is_root']= dataset['is_root'].astype('category')   # chenge cat data into binary
dataset['is_root']= dataset['is_root'].cat.codes
######################################## Split data ###########################
X = dataset.iloc[:, 1:4].values
y = dataset.iloc[:, 4:5].values
######## Add feature X0 = 1 
X = np.column_stack(( np.ones(len(X)),X))
X_training, X_validation, X_test = X[:10000,:], X[10000:11000,:], X[11000:12000,:]
y_training, y_validation, y_test = y[:10000,], y[10000:11000,], y[11000:12000,]

####################################### Word feature ##########################
#1-Cleaning the texts
def input_column(column,start, end ):
    textt = []
    for i in range(start, end): # for final run --> change it to : range(0,len(X_training))
        review = re.sub('[^a-zA-Z]', ' ', column[i])
        review = review.lower()
        review = review.split()
#        ps = PorterStemmer()
#        review = [ps.stem(word) for word in review if not word in set(stopwords.words('english'))]
        review = ' '.join(review)
        textt.append(review)
    return textt      
#2-Bag of words     
#2-1 :Apply tokenization to all sentences
def tokenize(sentences):
    words = []
    for sentence in sentences:
        w = word_extraction(sentence)
        words.extend(w)
    word_counts = collections.Counter(words)
#    for word, count in sorted(word_counts.items()):
#        print('"%s" is repeated %d time%s.' % (word, count, "s" if count > 1 else "")) 
#    sorted(word_counts.items(), key=lambda item: item[1])
    sort=[pair[0] for pair in sorted(word_counts.items(),reverse=True, key=lambda item: item[1])]
#    print ("dictionary of words and their frequncy is :{}".format(word_counts))
#    print('the list of words sorted by frequnce is:{}'.format(sort))
    return sort
#2-2:do text cleaning 
def word_extraction(sentence):
    ignore = []
    words = re.sub("[^\w]", " ",  sentence).split()
    cleaned_text = [w.lower() for w in words if w not in ignore]
    return cleaned_text    
#2-3:creating vector of word for each lines of text feature  
def generate_bow(allsentences,feature_range):    
    vocab = tokenize(allsentences)
    vocab = vocab[:feature_range]
#    print("Word List for Document \n{0} \n".format(vocab));
    text_vectort=[]
    for sentence in allsentences:
        words = word_extraction(sentence)
        bag_vector = np.zeros(len(vocab))
        for w in words:
            for i,word in enumerate(vocab):
                if word == w: 
                    bag_vector[i] += 1
        text_vectort.append(bag_vector)    
#        print("{0} \n{1}\n".format(sentence,np.array(bag_vector)))  
    return(text_vectort)

################ Closed form Solution #########################################
def ClosedForm(X,y):
    start = time.time()
    Xt_closed = transpose(X)
    product = dot(Xt_closed, X)
    theInverse = inv(product)
    w_closed = dot(theInverse, dot(Xt_closed, y))
    end = time.time()
    runtime = end-start
    return runtime, w_closed 

################ Gradient descent method ######################################
def GeadientDecsent( X, y):
    start = time.time()
    error=1
    step =1
    tol=10e-09 #tolerance value
    def calculate(delw,step):
        eta=0.00001
        beta=0.0001 #have to check as it takes a lot of time to convergence on setting this value
        decay = eta / (1 + beta * step)
        return decay * delw   
    W = np.random.rand(X.shape[1], 1) 
    w_gradient = np.ones((X.shape[1], 1))
    XTX = (X.T).dot(X)
    XTY = (X.T).dot(y)
    erro_vec = []
    steps_vec = []
    while (error > tol): #Algorithm
                delw = 2 * dot(XTX,W) - XTY
                W =W- calculate(delw,step)
                error = np.linalg.norm(np.abs(w_gradient - W), 2)
                erro_vec.append(error)
                w_gradient = W.copy()
                step=step+1  
                steps_vec.append(step)
    end = time.time()
    runtime = end-start
    return runtime, error, step, w_gradient

############## Mean Square Error ##############################################
def Mse(X,y,w):
    y_pred = dot( X, w)
    final = y - y_pred
    Mse_result = np.square(final).mean()
    return Mse_result

################### TAAAASSSSKKKKK 3-1 ########################################
###############################################################################  
##TRAINING########  
################Closed form Solution
runtime_closed_training, w_closed_training=ClosedForm(X_training,y_training)
Mse_closed_training = Mse(X_training,y_training, w_closed_training)
################Gradient descent method
runtime_gradient_training, error_gradient_training, step_gradient_training, w_gradient_training = GeadientDecsent( X_training, y_training)
Mse_Gradient_training= Mse(X_training,y_training,w_gradient_training)

##VALIDATION####### 
################Closed form Solution
runtime_closed_validation,w_closed_validation=ClosedForm(X_validation,y_validation)
Mse_closed_validation = Mse(X_validation,y_validation, w_closed_validation)
################Gradient descent method
runtime_gradient_validation, error_gradient_validation, step_gradient_validation, w_gradient_validation = GeadientDecsent( X_validation, y_validation)
Mse_Gradient_validation= Mse(X_validation,y_validation,w_gradient_validation)
 
################### TAAAASSSSKKKKK 3-2 ########################################
###############################################################################


###############################################################################
################################# 60 ##########################################

##TRAINING########  
################ add text feature to data set 
################################################(inputvector                 ,from,to             ),range_of_bagOfWord))
My_text_vector_training_60= np.asarray(generate_bow(input_column(dataset['text'],0   ,len(X_training)),    60            ))
New_X_training = np.column_stack((X_training, My_text_vector_training_60))
################Closed form Solution
runtime_closed_training_60, w_closed_training_60=ClosedForm(New_X_training,y_training)
Mse_closed_training_60 = Mse(New_X_training,y_training, w_closed_training_60)
################Gradient descent method
runtime_60, error_60, step_60, w_gradient_training_60 = GeadientDecsent( New_X_training, y_training)
Mse_Gradient_training_60 = Mse(New_X_training,y_training,w_gradient_training_60)

##VALIDATION####### 
################ add text feature to data set 
##################################################(inputvector                 ,from ,to                     ),range_of_bagOfWord))
My_text_vector_validation_60= np.asarray(generate_bow(input_column(dataset['text'],10000,10000+len(X_validation)),    60            ))
New_X_validation = np.column_stack((X_validation, My_text_vector_validation_60))
################Closed form Solution
runtime_closed_validation_60, w_closed_validation_60=ClosedForm(New_X_validation,y_validation)
Mse_closed_validation_60 = Mse(New_X_validation,y_validation, w_closed_validation_60)
################Gradient descent method
runtime_60, error_60, step_60, w_gradient_validation_60 = GeadientDecsent( New_X_validation, y_validation)
Mse_Gradient_validation_60= Mse(New_X_validation,y_validation,w_gradient_validation_60)


###############################################################################
################################# 160 #########################################

##TRAINING########  
################ add text feature to data set 
################################################(inputvector                 ,from,to             ),range_of_bagOfWord))
My_text_vector_training_160= np.asarray(generate_bow(input_column(dataset['text'],0   ,len(X_training)),    160            ))
New_X_training = np.column_stack((X_training, My_text_vector_training_160))
################Closed form Solution
runtime_closed_training_160, w_closed_training_160=ClosedForm(New_X_training,y_training)
Mse_closed_training_160 = Mse(New_X_training,y_training, w_closed_training_160)
################Gradient descent method
runtime_160, error_160, step_160, w_gradient_training_160 = GeadientDecsent( New_X_training, y_training)
Mse_Gradient_training_160= Mse(New_X_training,y_training,w_gradient_training_160)

##VALIDATION####### 
################ add text feature to data set 
##################################################(inputvector                 ,from ,to                     ),range_of_bagOfWord))
My_text_vector_validation_160= np.asarray(generate_bow(input_column(dataset['text'],10000,10000+len(X_validation)),    160            ))
New_X_validation = np.column_stack((X_validation, My_text_vector_validation_160))
################Closed form Solution
runtime_closed_validation_160, w_closed_validation_160=ClosedForm(New_X_validation,y_validation)
Mse_closed_validation_160 = Mse(New_X_validation,y_validation, w_closed_validation_160)
################Gradient descent method
runtime_160, error_160, step_160, w_gradient_validation_160 = GeadientDecsent( New_X_validation, y_validation)
Mse_Gradient_validation_160= Mse(New_X_validation,y_validation,w_gradient_validation_160)


################### TAAAASSSSKKKKK 3-3 ########################################
###############################################################################

############################### Feature One ###################################
 
################ add SQUARE feature to data set 
def featureOne(X):
    sliced = X[:, 1:2]
    new_feature_one= np.square(sliced)
    X_with_new_feature = np.column_stack((X,new_feature_one ))
    return X_with_new_feature

##TRAINING######## 
#################################################################(inputvector    ,from,to             ),range_of_bagOfWord))
My_text_vector_training_160= np.asarray(generate_bow(input_column(dataset['text'],0   ,len(X_training)),    160            ))
New_X_training_f1 = np.column_stack((featureOne(X_training), My_text_vector_training_160))
################Closed form Solution
runtime_closed_training_160_f1, w_closed_training_160_f1=ClosedForm(New_X_training_f1,y_training)
Mse_closed_training_160_f1 = Mse(New_X_training_f1,y_training, w_closed_training_160_f1)


############################### FeatureTwo ###################################
 
################ add EXP feature to data set 
def featureTwo(X):
    sliced = X[:, 1:2]
    new_feature_two= np.exp(sliced)
    X_with_new_feature = np.column_stack((X,new_feature_two ))
    return X_with_new_feature

##TRAINING######## 
#################################################################(inputvector    ,from,to             ),range_of_bagOfWord))
My_text_vector_training_160= np.asarray(generate_bow(input_column(dataset['text'],0   ,len(X_training)),    160            ))
New_X_training_f2 = np.column_stack((featureTwo(X_training), My_text_vector_training_160))
################Closed form Solution
runtime_closed_training_160_f2, w_closed_training_160_f2=ClosedForm(New_X_training_f2,y_training)
Mse_closed_training_160_f2 = Mse(New_X_training_f2,y_training, w_closed_training_160_f2)

############################### BOTH Features ###################################
 
################ add Both( SQUARE and EXP) features to data set 
def featureBoth(X):
    sliced = X[:, 1:2]
    new_feature_one= np.square(sliced)
    new_feature_two= np.exp(sliced)
    X_with_new_feature_both = np.column_stack((X, new_feature_one, new_feature_two))
    return X_with_new_feature_both
##TRAINING######## 
#################################################################(inputvector    ,from,to             ),range_of_bagOfWord))
My_text_vector_training_160= np.asarray(generate_bow(input_column(dataset['text'],0   ,len(X_training)),    160            ))
New_X_training_f1f2 = np.column_stack((featureBoth(X_training), My_text_vector_training_160))
################Closed form Solution
runtime_closed_training_160_f1f2, w_closed_training_160_f1f2=ClosedForm(New_X_training_f1f2,y_training)
Mse_closed_training_160_f1f2 = Mse(New_X_training_f1f2,y_training, w_closed_training_160_f1f2)

##VALIDATION######## 
#################################################################(inputvector    ,from,to             ),range_of_bagOfWord))
My_text_vector_validation_160= np.asarray(generate_bow(input_column(dataset['text'],10000,10000+len(X_validation)),    160            ))
New_X_validation_f1f2 = np.column_stack((featureBoth(X_validation), My_text_vector_validation_160))
################Closed form Solution
runtime_closed_validatin_160_f1f2, w_closed_validation_160_f1f2=ClosedForm(New_X_validation_f1f2,y_validation)
Mse_closed_validation_160_f1f2 = Mse(New_X_validation_f1f2,y_validation, w_closed_validation_160_f1f2)

##TEST######## 
#################################################################(inputvector    ,from,to             ),range_of_bagOfWord))
My_text_vector_test_160= np.asarray(generate_bow(input_column(dataset['text'],11000,11000+len(X_test)),    160            ))
New_X_test_f1f2 = np.column_stack((featureBoth(X_test), My_text_vector_test_160))
################Closed form Solution
runtime_closed_test_160_f1f2, w_closed_test_160_f1f2=ClosedForm(New_X_test_f1f2,y_test)
Mse_closed_test_160_f1f2 = Mse(New_X_test_f1f2,y_test, w_closed_test_160_f1f2)






